/*******************************************************************************
* File Name: DAC_NEG.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DAC_NEG_H) /* Pins DAC_NEG_H */
#define CY_PINS_DAC_NEG_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DAC_NEG_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DAC_NEG__PORT == 15 && ((DAC_NEG__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    DAC_NEG_Write(uint8 value) ;
void    DAC_NEG_SetDriveMode(uint8 mode) ;
uint8   DAC_NEG_ReadDataReg(void) ;
uint8   DAC_NEG_Read(void) ;
uint8   DAC_NEG_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DAC_NEG_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DAC_NEG_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DAC_NEG_DM_RES_UP          PIN_DM_RES_UP
#define DAC_NEG_DM_RES_DWN         PIN_DM_RES_DWN
#define DAC_NEG_DM_OD_LO           PIN_DM_OD_LO
#define DAC_NEG_DM_OD_HI           PIN_DM_OD_HI
#define DAC_NEG_DM_STRONG          PIN_DM_STRONG
#define DAC_NEG_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DAC_NEG_MASK               DAC_NEG__MASK
#define DAC_NEG_SHIFT              DAC_NEG__SHIFT
#define DAC_NEG_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DAC_NEG_PS                     (* (reg8 *) DAC_NEG__PS)
/* Data Register */
#define DAC_NEG_DR                     (* (reg8 *) DAC_NEG__DR)
/* Port Number */
#define DAC_NEG_PRT_NUM                (* (reg8 *) DAC_NEG__PRT) 
/* Connect to Analog Globals */                                                  
#define DAC_NEG_AG                     (* (reg8 *) DAC_NEG__AG)                       
/* Analog MUX bux enable */
#define DAC_NEG_AMUX                   (* (reg8 *) DAC_NEG__AMUX) 
/* Bidirectional Enable */                                                        
#define DAC_NEG_BIE                    (* (reg8 *) DAC_NEG__BIE)
/* Bit-mask for Aliased Register Access */
#define DAC_NEG_BIT_MASK               (* (reg8 *) DAC_NEG__BIT_MASK)
/* Bypass Enable */
#define DAC_NEG_BYP                    (* (reg8 *) DAC_NEG__BYP)
/* Port wide control signals */                                                   
#define DAC_NEG_CTL                    (* (reg8 *) DAC_NEG__CTL)
/* Drive Modes */
#define DAC_NEG_DM0                    (* (reg8 *) DAC_NEG__DM0) 
#define DAC_NEG_DM1                    (* (reg8 *) DAC_NEG__DM1)
#define DAC_NEG_DM2                    (* (reg8 *) DAC_NEG__DM2) 
/* Input Buffer Disable Override */
#define DAC_NEG_INP_DIS                (* (reg8 *) DAC_NEG__INP_DIS)
/* LCD Common or Segment Drive */
#define DAC_NEG_LCD_COM_SEG            (* (reg8 *) DAC_NEG__LCD_COM_SEG)
/* Enable Segment LCD */
#define DAC_NEG_LCD_EN                 (* (reg8 *) DAC_NEG__LCD_EN)
/* Slew Rate Control */
#define DAC_NEG_SLW                    (* (reg8 *) DAC_NEG__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DAC_NEG_PRTDSI__CAPS_SEL       (* (reg8 *) DAC_NEG__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DAC_NEG_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DAC_NEG__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DAC_NEG_PRTDSI__OE_SEL0        (* (reg8 *) DAC_NEG__PRTDSI__OE_SEL0) 
#define DAC_NEG_PRTDSI__OE_SEL1        (* (reg8 *) DAC_NEG__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DAC_NEG_PRTDSI__OUT_SEL0       (* (reg8 *) DAC_NEG__PRTDSI__OUT_SEL0) 
#define DAC_NEG_PRTDSI__OUT_SEL1       (* (reg8 *) DAC_NEG__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DAC_NEG_PRTDSI__SYNC_OUT       (* (reg8 *) DAC_NEG__PRTDSI__SYNC_OUT) 


#if defined(DAC_NEG__INTSTAT)  /* Interrupt Registers */

    #define DAC_NEG_INTSTAT                (* (reg8 *) DAC_NEG__INTSTAT)
    #define DAC_NEG_SNAP                   (* (reg8 *) DAC_NEG__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DAC_NEG_H */


/* [] END OF FILE */
